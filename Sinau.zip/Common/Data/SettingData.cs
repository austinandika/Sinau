﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Data
{
    [Serializable]
    public class SettingData
    {
        public string _AcademicYearID { get; set; }
        public string _AcademicYearName { get; set; }
    }
}
